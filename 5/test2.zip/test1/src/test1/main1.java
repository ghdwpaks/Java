package test1;

public class main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello world!");
		System.out.println("Hello world!");
	}

}
