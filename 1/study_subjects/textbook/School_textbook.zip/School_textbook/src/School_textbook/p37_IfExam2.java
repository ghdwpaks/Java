package School_textbook;

public class p37_IfExam2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 20, b = 10; char op = '*';
		if(op == '+') System.out.println(a + " + " + b + " = " +(a+b));
		else if(op == '-') System.out.println(a + " - " + b + " = " +(a+b));
		else if(op == '*') System.out.println(a + " * " + b + " = " +(a+b));
		else if(op == '/') System.out.println(a + " / " + b + " = " +(a+b));
		
		
		
	}

}
