package School_textbook;

public class p38_IfExam4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10;
		if(a) System.out.println(a + "�� 0�� �ƴմϴ�.");
		else System.out.println(a +"�� 0�Դϴ�.");
	}

}
