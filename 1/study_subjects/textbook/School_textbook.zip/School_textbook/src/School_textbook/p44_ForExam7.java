package School_textbook;

public class p44_ForExam7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 3; i >= 1; i--) {
			for (int j = 1; j <= i; j++) 
				System.out.print("*"+"\t");
			System.out.println("\n");
		}
	}

}
