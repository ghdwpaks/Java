package School_textbook;

public class p41_ForExam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 5 ; i++) 
			System.out.print(i + "\t");
		System.out.println();
		for (int i = 1; i <= 10 ; i++)
			System.out.print(i + "\t");
		System.out.println();
		for (int i = 10; i > 5 ; i--)
			System.out.print(i + "\t");
	}

}
