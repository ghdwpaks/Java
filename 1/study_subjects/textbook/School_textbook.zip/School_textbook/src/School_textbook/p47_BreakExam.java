package School_textbook;

public class p47_BreakExam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 0; i <= 10; i++) {
			if(i==5) break;
			System.out.print(i + "\t");
		}
	}

}
