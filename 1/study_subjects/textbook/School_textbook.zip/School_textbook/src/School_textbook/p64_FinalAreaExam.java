package School_textbook;

public class p64_FinalAreaExam {
	public static double PI = 3.14;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PI = 3.141492;
	}

}
