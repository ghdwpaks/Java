package School_textbook;

public class p59_ClassExam {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student59 kim = new Student59();
		kim.name = "������";
		kim.grade = 2 ;
		System.out.println("�л��� �̸��� "+kim.name+"�̰�, "+kim.grade+"�г��Դϴ�.");
	}

}
class Student59 {
	String name;
	int grade;
	int ban;
	int number;
	String telephone;
}
