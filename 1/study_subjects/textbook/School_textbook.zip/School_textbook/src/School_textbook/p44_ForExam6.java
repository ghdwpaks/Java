package School_textbook;

public class p44_ForExam6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 3; i++) {
			for (int j = 1; j <= i; j++) 
				System.out.println("*"+"\t");
			System.out.println("\n");
		}
	}

}
