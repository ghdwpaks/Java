package School_textbook;

public class p45_WhileExam1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		while (i <= 5) {
			System.out.println(i+"\t");
			i++;
		}
	}

}
